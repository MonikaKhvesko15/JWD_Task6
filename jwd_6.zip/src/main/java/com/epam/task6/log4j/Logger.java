package com.epam.task6.log4j;

public class Logger {

    }
