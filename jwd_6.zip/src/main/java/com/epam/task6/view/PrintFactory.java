package com.epam.task6.view;

public interface PrintFactory {
    Printer createPrinter();
}
