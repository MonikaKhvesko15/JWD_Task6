package com.epam.task6.logic;

public enum Field {
    TITLE,AUTHOR,PAGES,PRICE;
}
